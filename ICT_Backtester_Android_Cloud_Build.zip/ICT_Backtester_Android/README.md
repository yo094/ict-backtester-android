# ICT Backtester — Android APK project

This project packages the supplied `ICT Backtester` app inside an Android application. The app's HTML, web manifest and service worker are bundled under `app/src/main/assets`, so the Android app does not rely on the Netlify site or its temporary embed URL.

## Build the APK in the cloud (no Android Studio required)

1. Sign in to GitHub and create a **new private repository** named `ict-backtester-android`.
2. Upload the contents of this project folder to the repository's root (not the outer ZIP folder). The `.github/workflows/build-apk.yml` file must be included.
3. Open the repository's **Actions** tab. If GitHub asks, enable Actions for the repository.
4. Select **Build ICT Backtester APK** and press **Run workflow**. (A push to `main` also starts a build.)
5. Wait for the workflow to finish with a green check.
6. Open the completed workflow run and find **Artifacts** near the bottom. Download `ICT-Backtester-Android-APK`.
7. Extract the downloaded artifact ZIP. Open `app-debug.apk` on your Android phone and approve installation if prompted.

## What is included

- Android launcher app named **ICT Backtester** with a custom icon.
- The exact web app supplied in the ZIP is bundled into the app, not loaded from Netlify.
- WebView DOM storage retains the journal on that device.
- JSON import file picker and export download support are wired for Android.
- The original dashboard, journal, calendar, graphs, setup/session analytics and checklist are preserved.

## Notes

- This is a personal-install debug APK. It is not signed for Play Store distribution.
- Keep using the app's JSON export feature to back up trade history. Uninstalling or clearing app storage can erase local records.
- First cloud build downloads Android build dependencies and therefore needs internet. The installed app's core content is bundled locally.
